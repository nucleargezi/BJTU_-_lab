// Code by MeIoN ( without The Photo of MeIoN
#pragma region
#ifdef MeIoN
#include <MeIoN_H.hpp>
#include <MeIoN_debug.hpp>
#include <MeIoN_sth_for_os.hpp>
#else
#include <bits/stdc++.h>
#include <sys/wait.h>
#define debug(...) void(0721)
#endif

using   std::vector, std::array, std::pair, std::set, std::map, std::tuple, 
        std::bitset, std::unordered_map, std::multiset, std::priority_queue, 
        std::string, std::stack, std::less, std::greater;

using NAME = void;       using uint = unsigned;   using ll = long long;      using ull = unsigned long long;     
using ld = long double;  using i128 = __int128_t; using u128 = __uint128_t;  using f128 = __float128;

namespace MeIoN_Better_DS {
    template<class T> struct MeIoN_queue {
        vector<T> q;
        int pos = 0;
        void reserve(int n) { q.reserve(n); }
        int size() const { return int(q.size()) - pos; }
        bool empty() const { return pos == int(q.size()); }
        T& front() { return q[pos]; }
        template<typename... Args>
        void emplace_back(Args&&... args) { q.emplace_back(std::forward<Args>(args)...); }
        void push_back(const T &v) { q.push_back(v); }
        void pop() { ++pos; }
        void clear() {
            q.clear();
            pos = 0;
        }
    };
    // to do ?
}
#pragma endregion

// #define tests

using token_type = int;
constexpr token_type error = 0,
                     keyword = 1,
                     comment = 2,
                     variable = 3,
                     unsigned_int = 4,
                     single_operator = 5,
                     double_operator = 6;

const vector<string> keywords {
    "void", "int", "float", "double", "if", "else", "for", "do", 
    "while", "return", "switch", "case", "break", "continue", "default"
};

const string single_operators {"+-*/;(),={}\""};

const vector<string> double_operators {
    "++", "--", "+=", "-=", "*=", "/=", ">>", 
    "<<", "&&", "||", "!=", "==", "<=", ">="
};

token_type get_token_type(const string &token) {
    const int n = token.length();
    // ketwords ? 
    for (const string &s : keywords) {
        if (token == s) return keyword;
    }
    // double operator ? 
    for (const string &s : double_operators) {
        if (token == s) return double_operator;
    }
    // single operator
    for (const char c : single_operators) {
        if (c == token[0]) return single_operator;
    }
    // unsigned int ? 
    if (not not std::isdigit(token[0])) {
        int _ok = 1;
        for (int i = 1; i < n and _ok; ++i) {
            _ok &= not not std::isdigit(token[i]);
        }
        return _ok ? unsigned_int : error;
    }
    // variable ? 
    if (not not std::isalpha(token[0]) or token[0] == '_') {
        int _ok = 1;
        for(int i = 1; i < n and _ok; ++i) {
            _ok &=not not std::isalnum(token[i]) and token[i] != '_';
        }
        return _ok ? variable : error;
    }
    return error;
}

inline vector<string> get_token(string input) {
    while (not input.empty() and input.back() == '\n') input.pop_back();
    static string token;
    std::istringstream _tmp(input);
    vector<string> pretokens, tokens;
    
    while (std::getline(_tmp, token, '\n')) {
        pretokens.emplace_back(token);
    }

    for (const string s : pretokens) {
        _tmp = std::istringstream(s);
        while (std::getline(_tmp, token, ' ')) {
            if (token == "//") break;
            tokens.emplace_back(token);
        }
    }

    return tokens;
}

inline void out(const string &token, token_type type = -1) {
    if (not token.size()) return;
    if (not ~type) type = get_token_type(token);
    if (type == error) {
        return std::cout << "Error: \"" << token << "\"" << std::endl, void();
    }
    std::cout << "Token : (" << type << " " << token << ")" << std::endl;
}

inline void work(const string &token) {
    int sz = token.size();
    if (not sz) return;
    int i, pr;
    for (i = 0, pr = 0; i < sz; ++i) {
        if (not std::isalnum(token[i])) {
            if (i + 1 < sz and not std::isalnum(token[i + 1])) {
                out(token.substr(pr, i - pr));
                out(token.substr(i, 2));
                pr = i + 2;
                ++i;
            } else {
                out(token.substr(pr, i - pr));
                out(token.substr(i, 1));
                pr = i + 1;
            }
        }
    }
    out(token.substr(pr));
}

inline void go(const string &test_string) {
    vector tokens = get_token(test_string);
    for (int sz; string token : tokens) {
        work(token);
    }
}

inline NAME MeIoN_is_UMP45() {
    const string test_string[]{
        // 1
        "int main() { \n" \
            "std::cout << \"Ciallo World\" << std::endl; \n" \
            "sleep(1); \n" \
            "return 0; \n" \
        "} \n" ,
        // 2
        "int main() { \n" \
            "// 使用分隔符 \n" \
            "return 0; // 分号 \n" \
        "} \n", 
        // 3
        "if (condition) { \n" \
            "return 0; \n" \
        "} else { \n" \
            "while (true) { \n" \
                "// Do something \n" \
            "} \n" \
        "} \n",
        // 4
        "int sum = a + b;           // 加法运算符\n" \
        "int product = a * b;      // 乘法运算符\n" \
        "float result = x / y; \n"
    };
    debug(test_string[3]);
    go(test_string[3]);
}

// 日々を貪り尽くしてきた
int main() {
    std::cin.tie(0)->sync_with_stdio(false);
    int T = 1;
#ifdef tests
    std::cin >> T;
#endif
    while (T--) {
        MeIoN_is_UMP45();
    }
    return 0;
}